// ==========================================================
// INA219_0701_trainS3.ino (メインタブ)
// ==========================================================
#define EXTERN_MAIN 

#include <esp_now.h>
#include <WiFi.h>
#include "constant.h" // 💡 これにより sendData, recvData が自動で1度だけ定義されます
#include <Wire.h>
#include <Adafruit_INA219.h>

// 🔋 INA219のインスタンス（実体）はメイン側のここで定義します
Adafruit_INA219 ina219;

// タイマー変数
unsigned long lastVoltageTime = 0;

// 制御用変数
bool readyToSendDelay = false;     
float lastMeasuredDelay = 0.0;     
uint8_t targetSpeed2 = 0;          
float currentSpeed2 = 0.0;         

// ===== ESP-NOW 受信コールバック =====
// ===== ESP-NOW 受信コールバック =====
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 4, 0)
void OnDataRecv(const esp_now_recv_info *info, const uint8_t *incomingData, int len) {
  const uint8_t *mac = info->src_addr; 
#else
void OnDataRecv(const uint8_t *mac_addr, const uint8_t *incomingData, int len) {
  const uint8_t *mac = mac_addr;       
#endif

  if (len >= sizeof(CombinedPayload)) {
    CombinedPayload temp;
    memcpy(&temp, incomingData, sizeof(CombinedPayload));
    
    // 💡 自分自身がブロードキャスト送信した電波はMACアドレスの先頭(0xFF等)で完全に無視
    if (mac[0] == 0xFF) {
      return; 
    }
    
    // 🟢 ステーション（親機）からの本物の運行命令データだけを処理
    if (temp.header == 99 && temp.data88 == 88) {
      targetSpeed2 = temp.train2_speed; // モーター速度を安全に更新
      recvData = temp;
    }
  }
}
// ===== ESP-NOW 送信コールバック =====
void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {}

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  // XIAO ESP32-S3のI2Cピン初期化 (SDA:8, SCL:9)
  Wire.begin(8, 9); 
  if (!ina219.begin()) {
    Serial.println("INA219が見つかりません。");
  } else {
    Serial.println("INA219 初期化成功！");
  }

  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  ledcAttach(in1, freq, resolution);
  ledcAttach(in2, freq, resolution);
  
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  StatiNowpeer(); // 別タブのピア登録関数を呼び出す
  
  lastVoltageTime = millis(); 
  Serial.println("--- 列車2 起動完了 ---");
}

void loop() {

  // ⏱️ 1. 5秒ごとの電圧・電流送信タスク (readV.ino)
  readV(); 
  
  // 🚂 2. モーター制御処理 (CONTROL.ino の関数を呼び出す)
  // 受信した目標速度（targetSpeed2）が 0 ならブレーキ、それ以外なら前進させます
  if (targetSpeed2 == 0) {
    brake();  // CONTROL.ino にあるブレーキ関数
  } else {
    forward(targetSpeed2); // CONTROL.ino にある正転関数（指示された速度で回す）
  }
  
  delay(2);
}
