// 💡 constant.h で sendData などの実体を定義するために、インクルード前にこれを定義します
#define EXTERN_MAIN 

#include <esp_now.h>
#include <WiFi.h>
#include "constant.h"
#include <Wire.h>
#include <Adafruit_INA219.h>
Adafruit_INA219 ina219;

// グローバルでタイマー変数を実体化
unsigned long lastVoltageTime = 0;

// 不足していた制御用変数の定義
bool readyToSendDelay = false;      // 遅延送信フラグ
float lastMeasuredDelay = 0.0;     // 計測された遅延時間(ms)
uint8_t targetSpeed2 = 0;          // 列車2の目標速度
float currentSpeed2 = 0.0;         // 列車2の現在の速度

// ===== 受信コールバック（ここを修正） =====
void OnDataRecv(const esp_now_recv_info *info, const uint8_t *incomingData, int len) {
  // 1. 受信したデータを構造体に丸ごとコピー
  if (len == sizeof(recvData)) {
    memcpy(&recvData, incomingData, sizeof(recvData));
    
    // 2. 構造体の中の「列車2の速度」を、制御用の変数に代入
    targetSpeed2 = recvData.train2_speed;
  }
}
// ===== 送信コールバック（追加） =====
void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  // 送信結果をシリアルモニタで確認したい場合はここに処理を書けます
}
void setup() {
  Serial.begin(115200);
  delay(1000);
  
  // 💡【ここを追加】XIAO ESP32-S3のピン(SDA=8, SCL=9)でI2Cを開始し、INA219を初期化
  Wire.begin(8, 9); 
  if (!ina219.begin()) {
    Serial.println("INA219が見つかりません。配線を確認してください。");
  } else {
    Serial.println("INA219 初期化成功！");
  }

  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  ledcAttach(in1, freq, resolution);
  ledcAttach(in2, freq, resolution);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  StatiNowpeer();
  
  lastVoltageTime = millis(); // タイマースタート
  Serial.println("--- 列車2：電波受信＆モーター回転両立 確定版 起動完了 ---");
  
}

void loop() {
  // ⏱️ 1. 停止指示があった場合は、その「内部遅延ms」をモニターへ即時送信
  if (readyToSendDelay) {
    readyToSendDelay = false;
    
    sendData.header = 99;
    sendData.data88 = 66; // 列車2内部遅延専用コード
    sendData.voltage = lastMeasuredDelay; 
    
    esp_now_send(broadcastAddress, (uint8_t *)&sendData, sizeof(sendData));
    Serial.print("【📡 送信】列車2内部遅延: ");
    Serial.println(lastMeasuredDelay, 0);
  }

  // 🔋 2. 定期的なバッテリー電圧送信（readV.ino）
  readV();
// ⚙️ 3. モーターの加減速処理と回転指示
  if (targetSpeed2 > 0) {
    // 指示された速度に向けてスムーズに加速（しゃくり防止）
    currentSpeed2 += ((float)targetSpeed2 - currentSpeed2) * 0.25;
    forward((uint32_t)(currentSpeed2 + 0.5));
  } else {
    // 速度指示が0の時はブレーキ（停止）を維持
    brake();
    currentSpeed2 = 0.0;
  }
  
  delay(20); 
}
  // モーター制御など（元のスケッチのまま）
