#include "constant.h"
#include <esp_now.h>
#include <Wire.h>
#include <Adafruit_INA219.h>

// メイン側で実体化したタイマー変数を外部参照
extern unsigned long lastVoltageTime;
const unsigned long voltageInterval = 5000; // 5秒ごとに交互送信

// INA219のインスタンス
extern Adafruit_INA219 ina219;

// ==========================================================
// 🚀 メインの送信処理（余計なメモリを一切使わない安全設計）
// ==========================================================
void readV() {
  if (millis() - lastVoltageTime >= voltageInterval) {
    lastVoltageTime = millis();
    
    static bool sendFlip = false;
    sendFlip = !sendFlip; // 5秒ごとに電圧と電流の送信を切り替える

    // 💡 メモリ化けを防ぐため、ローカル変数は一切作らず、
    // メイン側で綺麗に確保されているグローバル変数「sendData」をそのまま使います。
    sendData.header = 99; // 共通電波コード

    if (sendFlip) {
      // 🔋 電圧データをセット
      float currentVolt = ina219.getBusVoltage_V();
      sendData.data88 = 88; // モニター側に電圧だと知らせる識別コード
      sendData.voltage = currentVolt;

      Serial.print("【🔋 INA219 送信】電圧: ");
      Serial.print(currentVolt);
      Serial.println(" V");
    } else {
      // 🔌 電流データをセット
      float currentmA = ina219.getCurrent_mA();
      sendData.data88 = 85; // モニター側に電流だと知らせる識別コード
      sendData.voltage = currentmA; // floatの領域にmAをそのままのせる

      Serial.print("【🔌 INA219 送信】電流: ");
      Serial.print(currentmA);
      Serial.println(" mA");
    }
    
    // 元々メイン側にある「sendData」のサイズ（24バイト）で安全に送信
    esp_now_send(broadcastAddress, (uint8_t *)&sendData, sizeof(sendData));
  }
}