// Broad_Train-1 (超即応・強力逆転カウンターブレーキ特化版)
#include <esp_now.h>
#include <WiFi.h>

/* 使うピンの定義 (ESP32 DEV用) */
const int IN1 = 23;
const int IN2 = 22;

const int LEDC_TIMER_BIT = 9;   // PWMの範囲 (10bit相当、0〜512)
const int LEDC_BASE_FREQ = 100;  // 周波数(Hz)
const int VALUE_MAX = 512;      // PWMの最大値

// 💡 調整パラメータ：トルクの弱さに合わせて逆転時間を調整してください
const unsigned long COUNTER_BRAKE_MS = 40; // 💡 逆転ブレーキをかける時間（ミリ秒）

// 💡 走行のスムーズ管理変数
volatile uint32_t targetSpeed = 0; 
float currentSpeed = 0.0;          

// ⏱️ 列車1用・遅延計測変数
unsigned long stopSignalReceivedTime = 0;
float lastMeasuredDelay = 0.0; // モニター送信用の遅延記録
bool readyToSendDelay = false;  // loop側へ安全に送信指示を出すフラグ

// ==========================================================
// 🎯 送受信共通の24バイト統合構造体（ステーションと完全一致）
// ==========================================================
struct __attribute__((packed)) CombinedPayload {
  uint8_t header;       // data[0]  (99)
  uint8_t train1_speed; // data[1]  ← 列車1自身の速度指示！
  uint8_t fb_light3;    // data[2]
  uint8_t train2_speed; // data[3]
  uint8_t fb_light4;    // data[4]
  uint8_t train3_speed; // data[5]
  uint8_t data5_light;  // data[6]
  uint8_t train4_speed; // data[7]
  uint8_t data6_light;  // data[8]
  uint8_t train1_poji;  // data[9]
  uint8_t train2_poji;  // data[10]
  uint8_t train3_poji;  // data[11]
  uint8_t train4_poji;  // data[12]
  uint8_t Data5_SIn;    // data[13]
  uint8_t Data6_SOut;   // data[14]
  uint8_t Data7_Sub;    // data[15]
  uint8_t Data8_Main;   // data[16]
  uint8_t ctr;          // data[17]
  uint8_t startbutton;  // data[18]
  uint8_t data88;       // data[19]  (88)
  
  float voltage;        // 💡 列車1の「遅延ミリ秒結果」をここに載せてステーションへ送り返す！
};

CombinedPayload recvData; 
CombinedPayload sendData; // 送信用箱
esp_now_peer_info_t slave;

// 💡 通常走行用のモーター制御関数
void forward(uint32_t pwm) {
  if (pwm > VALUE_MAX) pwm = VALUE_MAX;
  ledcWrite(IN1, pwm);
  ledcWrite(IN2, 0);
}

// === 🎯 最速電波受信コールバック ===
void OnDataRecv(const esp_now_recv_info *info, const uint8_t *incomingData, int len) {
  if (len >= sizeof(CombinedPayload)) {
    CombinedPayload temp;
    memcpy(&temp, incomingData, sizeof(CombinedPayload));
    
    // ステーションからの運行指示（header=99, data88=88）をチェック
    if (temp.header == 99 && temp.data88 == 88) {
      
      // ⏱️ 走行中(targetSpeed > 0)に、新しく「速度0（停止指示）」が届いた瞬間を検知
      if (targetSpeed > 0 && temp.train1_speed == 0) {
        stopSignalReceivedTime = millis(); // 受信した瞬間を記録
        currentSpeed = 0.0;

        // 🔥【超即応・強力逆転カウンターブレーキ】
        // トルクの弱さをカバーするため、一瞬だけ全力でモーターを「逆回転」させて急停止させます
        ledcWrite(IN1, 0); 
        ledcWrite(IN2, VALUE_MAX); 
        delayMicroseconds(COUNTER_BRAKE_MS * 1000); // 指定ミリ秒だけ逆転を維持

        // 🛑 その後、即座に両方HIGHのショートブレーキに切り替えて完全ロック
        ledcWrite(IN1, VALUE_MAX); 
        ledcWrite(IN2, VALUE_MAX);
        
        // ⏱️ ブレーキ完了後に内部タイムラグを計算
        stopSignalReceivedTime = millis() - stopSignalReceivedTime;
        lastMeasuredDelay = (float)stopSignalReceivedTime;
        readyToSendDelay = true; // loop側へ「ステーションへ遅延msを送れ」と合図
      }

      // 速度データを本番用の変数に反映
      targetSpeed = temp.train1_speed;
      recvData = temp;
    }
  }
}

void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {}

void setup() {
  Serial.begin(115200);
  pinMode(IN1, OUTPUT); 
  pinMode(IN2, OUTPUT); 

  ledcAttach(IN1, LEDC_BASE_FREQ, LEDC_TIMER_BIT);
  ledcAttach(IN2, LEDC_BASE_FREQ, LEDC_TIMER_BIT);
  
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  if (esp_now_init() != ESP_OK) {
    return;
  }
  
  // ブロードキャスト設定 (0xFF)
  memset(&slave, 0, sizeof(slave));
  for (int i = 0; i < 6; ++i) {
    slave.peer_addr[i] = (uint8_t)0xff;
  }
  esp_now_add_peer(&slave);
  
  esp_now_register_recv_cb(OnDataRecv);
  esp_now_register_send_cb(OnDataSent);
  
  Serial.println("--- 列車1：超即応カウンターブレーキ版 起動完了 ---");
}

void loop() {
  // ⏱️ 停止電波を処理した後、メイン処理(loop)から安全にステーションへ実測遅延時間を返信する
  if (readyToSendDelay) {
    readyToSendDelay = false; // フラグクリア
    
    Serial.print("【💡 列車1】停止電波受信からブレーキ反映までの実測時間: ");
    Serial.print(lastMeasuredDelay, 0);
    Serial.println(" ms (ミリ秒)");
    
    sendData.header = 99;
    sendData.data88 = 66;                 // 列車1の遅延ログだと判別させるための専用コード
    sendData.voltage = lastMeasuredDelay; // 遅延ミリ秒を格納して返信
    
    esp_now_send(slave.peer_addr, (uint8_t *)&sendData, sizeof(sendData));
  }

  // 💡 【ガクガク抹殺フィルター処理】通常走行時（targetSpeedが1以上）のみ動作
  if (targetSpeed > 0) {
    currentSpeed += ((float)targetSpeed - currentSpeed) * 0.25;
    forward((uint32_t)(currentSpeed + 0.5));
  }
  
  delay(20); 
}